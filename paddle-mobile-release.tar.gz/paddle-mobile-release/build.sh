CMAKE_CXX_FLAGS="-march=armv7-a -mfpu=neon -mfloat-abi=softfp"
CMAKE_CXX_FLAGS=${CMAKE_CXX_FLAGS}" -pie -fPIE -w -Wno-error=format-security"
CMAKE_CXX_FLAGS=${CMAKE_CXX_FLAGS}" -llog -landroid"

rm -rf build && mkdir build
cd build

cmake \
-DANDROID_ABI="armeabi-v7a with NEON" \
-DCMAKE_BUILD_TYPE="Release" \
-DCMAKE_TOOLCHAIN_FILE=../android.toolchain.cmake \
-DANDROID_PLATFORM="android-22" \
-DCMAKE_CXX_FLAGS=${CMAKE_CXX_FLAGS} \
-DANDROID_STL=c++_static \
-DUSE_OPENMP=ON \
-DLOG_PROFILE=ON \
-DDEBUGING=OFF \
..

make VERBOSE=1
