#include <sys/time.h>
#include <iostream>
#include "io/paddle_mobile.h"

namespace paddle_mobile {
paddle_mobile::PaddleMobileConfig CreatePaddleMobileConfig() {
  paddle_mobile::PaddleMobileConfig config;
  config.batch_size = 1;
  config.optimize = true;
//  config.thread_num = 1;
  config.model_dir = "./fsp_fc128_160";
  return config;
}
}

int main(int argc, char* argv[]) {
  auto config = paddle_mobile::CreatePaddleMobileConfig();
  paddle_mobile::PaddleMobile<paddle_mobile::CPU> predictor;
  predictor.SetThreadNum(4);

  predictor.Load(config);
  std::cout << "model load success..." << std::endl;

  int batch_size = 1;
  int channels = 3;
  int height = 112;
  int width = 112;
  paddle_mobile::framework::Tensor input;
  auto input_shape = paddle_mobile::framework::make_ddim(
      {batch_size, channels, height, width});
  input.Resize(input_shape);
  input.mutable_data<float>();

  std::cout << "feed input..." << std::endl;
  // feed input
  predictor.Feed(input, "feed");

  std::cout << "start predict..." << std::endl;
  // warm up
  predictor.Predict();

  timeval starttime, endtime;
  gettimeofday(&starttime, 0);

  // iter 10 times
  for (int i = 0; i < 10; ++i) {
    predictor.Predict();
  }

  gettimeofday(&endtime, 0);
  float timeuse = 1000000 * (endtime.tv_sec - starttime.tv_sec)
      + endtime.tv_usec - starttime.tv_usec;
  std::cout << "average elapsed: " << timeuse / 1000.0 / 10 << " ms" << std::endl;

  // fetch output tensor
  auto output = predictor.Fetch();
  return 0;
}
